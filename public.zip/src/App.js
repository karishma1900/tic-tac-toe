import logo from './logo.svg';
import './App.css';
import TicTacToe from './Components/TicTacToe/TicTacToe';

function App() {
  return (
   <div>
 <TicTacToe></TicTacToe>
   </div>
  );
}

export default App;
